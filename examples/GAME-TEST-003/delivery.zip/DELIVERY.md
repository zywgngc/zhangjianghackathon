# 游戏工程交付

状态：候选，尚未完成全部正式验收。具体依据见 delivery-status.json 与 evidence/ 中的原始报告。

直接打开 playable.html 可离线运行。源码与多文件构建位于 project/；不包含 node_modules、凭据或 .harness。
已安装生产依赖的许可证与声明文件位于 licenses/npm/，精确版本见 project/package-lock.json。
使用与仓库一致的 Python/Node 依赖后，可重新运行 scripts/validate_project.py 对源码独立验收。
